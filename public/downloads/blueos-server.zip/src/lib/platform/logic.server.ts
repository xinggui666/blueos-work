import { createHash, randomBytes } from "node:crypto";
import { getSql, type Sql } from "@/lib/db";
import { validateDsl, type Project, type Revision } from "@/lib/blueos/model";
import { CLIENTS, isSharedAction, type ClientKind } from "@/lib/contract/surface";
import {
  CONFIG_KEYS,
  QUOTA_KINDS,
  STARTER_QUOTA,
  accessReason,
  allows,
  isStaff,
  normalizeCode,
  roleChangeError,
  submissionIssues,
  type AccessRow,
  type QuotaKind,
} from "./policy";

type Row = Record<string, unknown>;

function id(prefix: string): string {
  return prefix + randomBytes(8).toString("hex");
}

function text(value: unknown, max = 200): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function obj(payload: unknown): Record<string, unknown> {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new Error("参数不正确");
  return payload as Record<string, unknown>;
}

function asJson(value: unknown): unknown {
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }
  return value;
}

function stamp(value: unknown): number {
  if (value instanceof Date) return value.getTime();
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? Date.now() : parsed;
  }
  return Date.now();
}

function iso(value: unknown): string | null {
  if (value == null) return null;
  const time = stamp(value);
  return new Date(time).toISOString();
}

async function one<T extends Row>(sql: Sql, query: string, params: unknown[] = []): Promise<T | null> {
  const rows = await sql.query<T>(query, params);
  return rows[0] ?? null;
}

async function audit(sql: Sql, actorId: string, action: string, target: string, before: unknown, after: unknown) {
  await sql.query(
    "insert into audit_logs (id, actor_id, action, target, before, after) values ($1,$2,$3,$4,$5::jsonb,$6::jsonb)",
    [id("a"), actorId, action, target, before == null ? null : JSON.stringify(before), after == null ? null : JSON.stringify(after)],
  );
}

async function configMap(sql: Sql): Promise<Record<string, string>> {
  const rows = await sql.query<{ key: string; value: string }>("select key, value from system_config");
  return Object.fromEntries(rows.map((row) => [row.key, row.value]));
}

async function rolesOf(sql: Sql, userId: string): Promise<string[]> {
  const rows = await sql.query<{ role: string }>("select role from user_roles where user_id = $1", [userId]);
  return rows.map((row) => row.role);
}

async function ensureQuota(sql: Sql, userId: string, kind: QuotaKind) {
  await sql.query(
    "insert into quota_accounts (user_id, kind, balance, reserved) values ($1,$2,0,0) on conflict (user_id, kind) do nothing",
    [userId, kind],
  );
}

async function ledger(sql: Sql, userId: string, kind: string, delta: number, phase: string, ref: string, note: string) {
  await sql.query(
    "insert into quota_ledger (id, user_id, kind, delta, phase, ref, note) values ($1,$2,$3,$4,$5,$6,$7)",
    [id("q"), userId, kind, delta, phase, ref, note],
  );
}

async function grantQuota(sql: Sql, userId: string, kind: QuotaKind, amount: number, phase: "grant" | "adjust", ref: string, note: string) {
  if (!Number.isInteger(amount) || amount === 0) return;
  await ensureQuota(sql, userId, kind);
  const updated = await sql.query(
    "update quota_accounts set balance = balance + $3 where user_id = $1 and kind = $2 and balance + $3 >= reserved returning balance",
    [userId, kind, amount],
  );
  if (!updated.length) throw new Error("额度不足，不能扣成负数");
  await ledger(sql, userId, kind, amount, phase, ref, note);
}

async function reserve(sql: Sql, userId: string, kind: QuotaKind, ref: string): Promise<boolean> {
  await ensureQuota(sql, userId, kind);
  const updated = await sql.query(
    "update quota_accounts set reserved = reserved + 1 where user_id = $1 and kind = $2 and balance - reserved >= 1 returning reserved",
    [userId, kind],
  );
  if (!updated.length) return false;
  await ledger(sql, userId, kind, 1, "reserve", ref, "预留 1");
  return true;
}

async function commitQuota(sql: Sql, userId: string, kind: QuotaKind, ref: string) {
  const updated = await sql.query(
    "update quota_accounts set balance = balance - 1, reserved = reserved - 1 where user_id = $1 and kind = $2 and reserved >= 1 and balance >= 1 returning balance",
    [userId, kind],
  );
  if (!updated.length) throw new Error("额度确认失败");
  await ledger(sql, userId, kind, -1, "commit", ref, "确认消耗 1");
}

async function release(sql: Sql, userId: string, kind: QuotaKind, ref: string, note: string) {
  const updated = await sql.query(
    "update quota_accounts set reserved = reserved - 1 where user_id = $1 and kind = $2 and reserved >= 1 returning reserved",
    [userId, kind],
  );
  if (updated.length) await ledger(sql, userId, kind, -1, "release", ref, note);
}

type Actor = {
  userId: string;
  email: string;
  name: string;
  status: string;
  developerStatus: string;
  roles: string[];
  created: boolean;
};

async function ensureActor(sql: Sql, userId: string): Promise<Actor> {
  const user = await one<{ email: string; name: string }>(sql, 'select email, name from "user" where id = $1', [userId]);
  if (!user) throw new Error("账号不存在");
  const existing = await one<{ status: string; developer_status: string }>(
    sql,
    "select status, developer_status from profiles where user_id = $1",
    [userId],
  );
  let created = false;
  if (!existing) {
    const open = (await configMap(sql)).registration_open !== "false";
    const supers = await one<{ count: number }>(sql, "select count(*)::int as count from user_roles where role = 'super_admin'");
    if ((supers?.count ?? 0) > 0 && !open) throw new Error("注册已关闭");
    const inserted = await sql.query(
      "insert into profiles (user_id, display_name) values ($1,$2) on conflict (user_id) do nothing returning user_id",
      [userId, user.name || ""],
    );
    created = inserted.length > 0;
  }
  const promoted = await sql.query(
    `insert into user_roles (user_id, role)
     select $1, 'super_admin'
     where not exists (select 1 from user_roles where role = 'super_admin')
     returning user_id`,
    [userId],
  );
  if (promoted.length) await audit(sql, userId, "bootstrap.super_admin", userId, null, { role: "super_admin" });
  if (created) {
    for (const kind of QUOTA_KINDS) {
      const amount = STARTER_QUOTA[kind];
      await ensureQuota(sql, userId, kind);
      const starter = await sql.query(
        "select id from quota_ledger where user_id = $1 and ref = 'starter' and kind = $2 limit 1",
        [userId, kind],
      );
      if (amount > 0 && !starter.length) await grantQuota(sql, userId, kind, amount, "grant", "starter", "新账号初始额度");
    }
  }
  const profile = await one<{ status: string; developer_status: string }>(
    sql,
    "select status, developer_status from profiles where user_id = $1",
    [userId],
  );
  if (!profile) throw new Error("账号资料没有建立");
  if (profile.status === "banned") throw new Error("账号已封禁");
  return {
    userId,
    email: user.email,
    name: user.name,
    status: profile.status,
    developerStatus: profile.developer_status,
    roles: await rolesOf(sql, userId),
    created,
  };
}

function requirePerm(actor: Actor, perm: string) {
  if (!allows(actor.roles, perm)) throw new Error("没有权限");
}

async function activeMembership(sql: Sql, userId: string) {
  return one<{ id: string; plan_id: string; ends_at: unknown; snapshot: unknown }>(
    sql,
    "select id, plan_id, ends_at, snapshot from memberships where user_id = $1 and ends_at > now() order by ends_at desc limit 1",
    [userId],
  );
}

async function quotaView(sql: Sql, userId: string) {
  const rows = await sql.query<{ kind: QuotaKind; balance: number; reserved: number }>(
    "select kind, balance, reserved from quota_accounts where user_id = $1",
    [userId],
  );
  const view = { generation: { balance: 0, reserved: 0 }, build: { balance: 0, reserved: 0 }, export: { balance: 0, reserved: 0 } };
  for (const row of rows) {
    if (row.kind in view) view[row.kind] = { balance: Number(row.balance), reserved: Number(row.reserved) };
  }
  return view;
}

async function componentRows(sql: Sql): Promise<AccessRow[]> {
  const rows = await sql.query<{ slug: string; access: string; status: string; name: string }>(
    "select slug, access, status, name from components",
  );
  return rows;
}

async function grantSet(sql: Sql, userId: string): Promise<Set<string>> {
  const rows = await sql.query<{ slug: string }>(
    `select c.slug from component_grants g join components c on c.id = g.component_id
     where g.user_id = $1 and (g.expires_at is null or g.expires_at > now())`,
    [userId],
  );
  return new Set(rows.map((row) => row.slug));
}

async function paletteFor(sql: Sql, userId: string, roles: string[]) {
  const [rows, member, grants] = await Promise.all([componentRows(sql), activeMembership(sql, userId), grantSet(sql, userId)]);
  const staff = allows(roles, "components.write");
  const palette: Record<string, string> = {};
  for (const row of rows) {
    palette[row.slug] = accessReason(row, { member: Boolean(member), granted: grants.has(row.slug), staff }) ?? "";
  }
  return palette;
}

function cleanProject(input: unknown): Project {
  const raw = JSON.stringify(input ?? null);
  if (raw.length > 400_000) throw new Error("工程过大");
  const project = input as Project;
  if (!project || typeof project !== "object") throw new Error("工程数据无效");
  if (!/^[a-z][a-z0-9]{6,40}$/.test(project.id || "")) throw new Error("工程编号无效");
  const name = text(project.name, 40);
  const appName = text(project.appName, 40);
  const packageName = text(project.packageName, 80);
  if (!name || !appName) throw new Error("请填写工程名和应用名");
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(packageName)) throw new Error("包名要像 com.example.watch");
  if (project.device !== "watch-round" && project.device !== "watch-square") throw new Error("设备类型无效");
  if (!Array.isArray(project.pages) || project.pages.length < 1 || project.pages.length > 12) throw new Error("页面数量无效");
  let nodes = 0;
  for (const page of project.pages) nodes += Array.isArray(page.nodes) ? page.nodes.length : 0;
  if (nodes > 200) throw new Error("组件太多");
  const revisions = Array.isArray(project.revisions) ? project.revisions.slice(0, 30) : [];
  for (const revision of revisions) {
    if (!revision || typeof revision.snapshot !== "string" || revision.snapshot.length > 150_000) throw new Error("修订快照无效");
  }
  return {
    ...project,
    name,
    appName,
    packageName,
    designWidth: 466,
    revisions,
  };
}

async function upsertProject(sql: Sql, userId: string, project: Project) {
  const body = { ...project, revisions: [] };
  const rows = await sql.query<{ id: string }>(
    `insert into projects (id, user_id, name, app_name, package_name, device, body, updated_at)
     values ($1,$2,$3,$4,$5,$6,$7::jsonb, now())
     on conflict (id) do update set
       name = excluded.name,
       app_name = excluded.app_name,
       package_name = excluded.package_name,
       device = excluded.device,
       body = excluded.body,
       updated_at = now()
     where projects.user_id = excluded.user_id
     returning id`,
    [project.id, userId, project.name, project.appName, project.packageName, project.device, JSON.stringify(body)],
  );
  if (!rows.length) throw new Error("这个工程不属于当前账号");
  for (const revision of project.revisions) {
    if (!/^[a-z][a-z0-9]{6,40}$/.test(revision.id)) continue;
    await sql.query(
      `insert into project_revisions (id, project_id, user_id, rev, note, snapshot)
       values ($1,$2,$3, coalesce((select max(rev) from project_revisions where project_id = $2), 0) + 1, $4, $5)
       on conflict (id) do nothing`,
      [revision.id, project.id, userId, text(revision.note, 80) || "修订", revision.snapshot],
    );
  }
}

function projectFrom(row: Row, revisions: Revision[]): Project {
  const body = asJson(row.body) as Project;
  return {
    ...body,
    id: String(row.id),
    name: String(row.name),
    appName: String(row.app_name),
    packageName: String(row.package_name),
    device: row.device === "watch-square" ? "watch-square" : "watch-round",
    designWidth: 466,
    updatedAt: stamp(row.updated_at),
    pages: Array.isArray(body.pages) ? body.pages : [],
    revisions,
  };
}

async function revisionsOf(sql: Sql, projectId: string): Promise<Revision[]> {
  const rows = await sql.query<{ id: string; note: string; snapshot: string; created_at: unknown }>(
    "select id, note, snapshot, created_at from project_revisions where project_id = $1 order by rev desc limit 30",
    [projectId],
  );
  return rows.map((row) => ({ id: row.id, note: row.note, snapshot: row.snapshot, at: stamp(row.created_at) }));
}

async function listProjects(sql: Sql, userId: string): Promise<Project[]> {
  const rows = await sql.query<Row>(
    "select id, name, app_name, package_name, device, body, updated_at from projects where user_id = $1 order by updated_at desc",
    [userId],
  );
  const projects: Project[] = [];
  for (const row of rows) projects.push(projectFrom(row, await revisionsOf(sql, String(row.id))));
  return projects;
}

async function concurrencyLimit(sql: Sql, userId: string): Promise<number> {
  const member = await activeMembership(sql, userId);
  if (!member) return 1;
  const plan = await one<{ concurrency: number }>(sql, "select concurrency from plans where id = $1", [member.plan_id]);
  return Math.max(1, Number(plan?.concurrency ?? 1));
}

async function runGeneration(sql: Sql, userId: string, dslInput: unknown) {
  const flags = await configMap(sql);
  if (flags.generation_enabled === "false") throw new Error("生成已关闭");
  const { dsl, issues } = validateDsl(dslInput);
  if (!dsl) return { ok: false as const, issues };
  const actor = await ensureActor(sql, userId);
  const palette = await paletteFor(sql, userId, actor.roles);
  const blocked = [...issues];
  dsl.pages.forEach((page, pageIndex) => {
    page.components.forEach((component, index) => {
      const reason = palette[component.type];
      if (reason === undefined) {
        blocked.push({ path: `pages/${pageIndex}/components/${index}`, message: `${component.type} 不在已上架目录`, level: "error" });
      } else if (reason) {
        blocked.push({ path: `pages/${pageIndex}/components/${index}`, message: reason, level: "error" });
      }
    });
  });
  if (blocked.some((issue) => issue.level === "error")) return { ok: false as const, issues: blocked };

  const digest = createHash("sha256").update(JSON.stringify(dsl)).digest("hex");
  const key = `gen:${digest}`;
  const existing = await one<Row>(
    sql,
    "select id, status, message, file_name, sha256, artifact, exported from jobs where user_id = $1 and idempotency_key = $2",
    [userId, key],
  );
  if (existing?.status === "succeeded" && existing.artifact) {
    const { buildArtifact } = await import("@/lib/blueos/emit.server");
    const again = buildArtifact(dsl);
    return again.ok
      ? { ...again, zipBase64: existing.exported ? again.zipBase64 : null, jobId: String(existing.id), reused: true }
      : again;
  }

  const open = await one<{ count: number }>(
    sql,
    "select count(*)::int as count from jobs where user_id = $1 and status = 'succeeded' and created_at > now() - interval '2 seconds'",
    [userId],
  );
  const limit = await concurrencyLimit(sql, userId);
  if ((open?.count ?? 0) >= limit) throw new Error("生成太密，请稍后再试");

  const jobId = existing?.id ? String(existing.id) : id("job");
  if (!existing) {
    await sql.query(
      "insert into jobs (id, user_id, project_id, kind, status, idempotency_key, message) values ($1,$2,$3,'generation','failed',$4,'处理中')",
      [jobId, userId, dsl.project.id, key],
    );
  }
  const reserved = await reserve(sql, userId, "generation", jobId);
  if (!reserved) {
    await sql.query("update jobs set status = 'failed', message = $2 where id = $1 and user_id = $3", [jobId, "生成额度不足", userId]);
    throw new Error("生成额度不足");
  }
  try {
    const { buildArtifact } = await import("@/lib/blueos/emit.server");
    const artifact = buildArtifact(dsl);
    if (!artifact.ok) {
      await release(sql, userId, "generation", jobId, "校验失败，释放预留");
      await sql.query("update jobs set status = 'failed', message = $2 where id = $1", [jobId, "DSL 校验失败"]);
      return artifact;
    }
    await commitQuota(sql, userId, "generation", jobId);
    let exported = false;
    let zip: string | null = artifact.zipBase64;
    const exportHeld = await reserve(sql, userId, "export", jobId);
    if (!exportHeld) {
      zip = null;
    } else {
      await commitQuota(sql, userId, "export", jobId);
      exported = true;
    }
    await sql.query(
      `update jobs set status = 'succeeded', message = $2, file_name = $3, sha256 = $4, artifact = $5, bytes = $6, exported = $7
       where id = $1`,
      [
        jobId,
        exported ? "source_zip 已生成，未编译" : "source_zip 已生成，导出额度不足，压缩包暂不提供",
        artifact.fileName,
        artifact.sha256,
        artifact.zipBase64,
        artifact.zipBase64.length,
        exported,
      ],
    );
    const notes = exported ? artifact.notes : [...artifact.notes, "导出额度不足。生成额度已确认，压缩包先留在任务里，补足导出额度后再下载。"];
    return { ...artifact, zipBase64: zip, notes, jobId, reused: false, compiled: false as const, artifactType: "source_zip" as const };
  } catch (error) {
    await release(sql, userId, "generation", jobId, "内部失败，释放预留");
    await sql.query("update jobs set status = 'failed', message = $2 where id = $1", [jobId, "生成失败"]);
    throw error;
  }
}

async function applyKey(sql: Sql, userId: string, type: string, payload: Record<string, unknown>, ref: string) {
  if (type === "membership" || (type === "custom" && payload.planId)) {
    const planId = text(payload.planId, 40);
    const plan = await one<Row>(sql, "select * from plans where id = $1 and active = true", [planId]);
    if (!plan) throw new Error("卡密里的套餐不存在");
    await giveMembership(sql, userId, plan, ref);
  }
  if (type === "quota" || type === "custom") {
    for (const kind of QUOTA_KINDS) {
      const amount = Number(payload[kind] ?? 0);
      if (amount > 0) await grantQuota(sql, userId, kind, Math.min(10_000, Math.floor(amount)), "grant", ref, "卡密充值");
    }
  }
  if (type === "component" || (type === "custom" && payload.componentId)) {
    const componentId = text(payload.componentId, 40);
    const found = await one(sql, "select id from components where id = $1", [componentId]);
    if (!found) throw new Error("卡密里的组件不存在");
    await sql.query(
      `insert into component_grants (user_id, component_id, source) values ($1,$2,$3)
       on conflict (user_id, component_id) do update set source = excluded.source`,
      [userId, componentId, ref],
    );
  }
}

async function giveMembership(sql: Sql, userId: string, plan: Row, source: string) {
  const current = await activeMembership(sql, userId);
  const start = current ? stamp(current.ends_at) : Date.now();
  const ends = new Date(start + Number(plan.duration_days) * 86_400_000);
  const snapshot = {
    id: plan.id,
    name: plan.name,
    slug: plan.slug,
    priceCents: plan.price_cents,
    durationDays: plan.duration_days,
    generation: plan.generation,
    build: plan.build_quota,
    export: plan.export_quota,
    concurrency: plan.concurrency,
  };
  await sql.query(
    "insert into memberships (id, user_id, plan_id, snapshot, starts_at, ends_at, source) values ($1,$2,$3,$4::jsonb,$5,$6,$7)",
    [id("m"), userId, plan.id, JSON.stringify(snapshot), new Date(start).toISOString(), ends.toISOString(), source],
  );
  await grantQuota(sql, userId, "generation", Number(plan.generation), "grant", source, `套餐 ${String(plan.name)} 生成额度`);
  await grantQuota(sql, userId, "export", Number(plan.export_quota), "grant", source, `套餐 ${String(plan.name)} 导出额度`);
  if (Number(plan.build_quota) > 0) await grantQuota(sql, userId, "build", Number(plan.build_quota), "grant", source, `套餐 ${String(plan.name)} 构建额度`);
}

function publicJob(row: Row) {
  return {
    id: String(row.id),
    projectId: String(row.project_id),
    kind: String(row.kind),
    status: String(row.status),
    message: String(row.message ?? ""),
    fileName: row.file_name ? String(row.file_name) : null,
    sha256: row.sha256 ? String(row.sha256) : null,
    exported: Boolean(row.exported),
    createdAt: iso(row.created_at),
  };
}

async function me(sql: Sql, actor: Actor) {
  const membership = await activeMembership(sql, actor.userId);
  const quota = await quotaView(sql, actor.userId);
  const palette = await paletteFor(sql, actor.userId, actor.roles);
  const announcements = await sql.query<{ id: string; title: string; body: string }>(
    "select id, title, body from announcements where active = true order by created_at desc limit 5",
  );
  const plans = await sql.query<Row>("select * from plans where active = true order by price_cents");
  return {
    userId: actor.userId,
    email: actor.email,
    name: actor.name,
    status: actor.status,
    developerStatus: actor.developerStatus,
    roles: actor.roles,
    staff: isStaff(actor.roles),
    membership: membership
      ? { planId: membership.plan_id, endsAt: iso(membership.ends_at), snapshot: asJson(membership.snapshot) }
      : null,
    quota,
    palette,
    announcements,
    plans: plans.map(planCard),
    flags: await configMap(sql),
    clients: CLIENTS,
  };
}

function planCard(plan: Row) {
  return {
    id: String(plan.id),
    slug: String(plan.slug),
    name: String(plan.name),
    priceCents: Number(plan.price_cents),
    durationDays: Number(plan.duration_days),
    generation: Number(plan.generation),
    build: Number(plan.build_quota),
    export: Number(plan.export_quota),
    concurrency: Number(plan.concurrency),
    active: Boolean(plan.active),
  };
}

function componentCard(row: Row, installed: boolean) {
  return {
    id: String(row.id),
    slug: String(row.slug),
    name: String(row.name),
    category: String(row.category),
    summary: String(row.summary),
    authorName: String(row.author_name),
    access: String(row.access),
    minPlan: String(row.min_plan ?? ""),
    status: String(row.status),
    latestVersion: String(row.latest_version),
    installed,
  };
}

export async function dispatch(userId: string, action: string, payload: unknown, client: ClientKind = "web"): Promise<unknown> {
  const sql = await getSql();
  const actor = await ensureActor(sql, userId);
  const body = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
  if (!action.startsWith("admin") && !isSharedAction(action)) throw new Error("这个接口没有对客户端开放");

  if (action === "me") return { ...(await me(sql, actor)), client };

  if (action === "listProjects") return listProjects(sql, userId);

  if (action === "syncProject") {
    const project = cleanProject(body.project);
    await upsertProject(sql, userId, project);
    return { ok: true };
  }

  if (action === "deleteProject") {
    const projectId = text(body.id, 48);
    await sql.query("delete from projects where id = $1 and user_id = $2", [projectId, userId]);
    return { ok: true };
  }

  if (action === "generate") return runGeneration(sql, userId, body.dsl);

  if (action === "listJobs") {
    const rows = await sql.query<Row>(
      "select id, project_id, kind, status, message, file_name, sha256, exported, created_at from jobs where user_id = $1 order by created_at desc limit 40",
      [userId],
    );
    return rows.map(publicJob);
  }

  if (action === "downloadJob") {
    const job = await one<Row>(
      sql,
      "select * from jobs where id = $1 and user_id = $2 and kind = 'generation'",
      [text(body.id, 48), userId],
    );
    if (!job || job.status !== "succeeded" || !job.artifact) throw new Error("没有可下载的源工程");
    if (!job.exported) {
      const held = await reserve(sql, userId, "export", String(job.id));
      if (!held) throw new Error("导出额度不足");
      await commitQuota(sql, userId, "export", String(job.id));
      await sql.query("update jobs set exported = true, message = $2 where id = $1", [job.id, "source_zip 已导出，未编译"]);
    }
    return {
      fileName: String(job.file_name),
      sha256: String(job.sha256),
      zipBase64: String(job.artifact),
      compiled: false,
      artifactType: "source_zip",
    };
  }

  if (action === "requestBuild") {
    const projectId = text(body.projectId, 48);
    const owned = await one(sql, "select id from projects where id = $1 and user_id = $2", [projectId, userId]);
    if (!owned) throw new Error("找不到这个工程");
    const jobId = id("job");
    const message = "官方 BlueOS 工具链没有在此环境验证。任务未执行编译，不能记为构建成功，也不扣构建额度。";
    await sql.query(
      "insert into jobs (id, user_id, project_id, kind, status, idempotency_key, message) values ($1,$2,$3,'build','unavailable',$4,$5)",
      [jobId, userId, projectId, `build:${jobId}`, message],
    );
    return { id: jobId, status: "unavailable", message };
  }

  if (action === "market") {
    const rows = await sql.query<Row>("select * from components where status = 'published' and access <> 'internal' order by category, name");
    const installed = await sql.query<{ component_id: string }>("select component_id from component_installs where user_id = $1", [userId]);
    const have = new Set(installed.map((row) => row.component_id));
    return rows.map((row) => componentCard(row, have.has(String(row.id))));
  }

  if (action === "install") {
    const flags = await configMap(sql);
    if (flags.marketplace_open === "false") throw new Error("商城已关闭");
    const component = await one<Row>(sql, "select * from components where id = $1", [text(body.componentId, 48)]);
    if (!component) throw new Error("组件不存在");
    const palette = await paletteFor(sql, userId, actor.roles);
    const reason = palette[String(component.slug)];
    if (reason) throw new Error(reason);
    await sql.query(
      `insert into component_installs (user_id, component_id, version) values ($1,$2,$3)
       on conflict (user_id, component_id) do update set version = excluded.version, installed_at = now()`,
      [userId, component.id, component.latest_version],
    );
    return { ok: true };
  }

  if (action === "redeem") {
    const code = normalizeCode(text(body.code, 40));
    if (!/^BH-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code)) throw new Error("卡密格式不对");
    const hash = createHash("sha256").update(code).digest("hex");
    const found = await one<Row>(sql, "select * from license_keys where code_hash = $1", [hash]);
    if (!found) {
      await sql.query("insert into license_activations (id, key_id, user_id, result) values ($1,$2,$3,$4)", [id("la"), "missing", userId, "not_found"]);
      throw new Error("卡密不存在");
    }
    if (found.status === "frozen") throw new Error("卡密已冻结");
    if (found.status === "void") throw new Error("卡密已作废");
    if (found.status === "used") throw new Error("卡密已使用");
    if (found.expires_at && stamp(found.expires_at) < Date.now()) {
      await sql.query("update license_keys set status = 'expired' where id = $1 and status = 'unused'", [found.id]);
      throw new Error("卡密已过期");
    }
    const payload = asJson(found.payload) as Record<string, unknown>;
    const updated = await sql.query(
      "update license_keys set status = 'used', used_by = $2, used_at = now() where id = $1 and status = 'unused' returning id",
      [found.id, userId],
    );
    if (!updated.length) throw new Error("卡密已使用");
    try {
      await applyKey(sql, userId, String(found.type), payload, String(found.id));
    } catch (error) {
      await sql.query("update license_keys set status = 'unused', used_by = null, used_at = null where id = $1 and used_by = $2", [found.id, userId]);
      throw error;
    }
    await sql.query("insert into license_activations (id, key_id, user_id, result) values ($1,$2,$3,'ok')", [id("la"), found.id, userId]);
    return { ok: true, type: found.type };
  }

  if (action === "listOrders") {
    const rows = await sql.query<Row>("select * from orders where user_id = $1 order by created_at desc limit 20", [userId]);
    return rows.map(orderCard);
  }

  if (action === "createOrder") {
    const plan = await one<Row>(sql, "select * from plans where id = $1 and active = true", [text(body.planId, 40)]);
    if (!plan) throw new Error("套餐不存在");
    const orderId = id("o");
    const snapshot = planCard(plan);
    await sql.query(
      "insert into orders (id, user_id, plan_id, status, amount_cents, snapshot, note) values ($1,$2,$3,'pending',$4,$5::jsonb,$6)",
      [orderId, userId, plan.id, plan.price_cents, JSON.stringify(snapshot), "等待人工确认，没有自动扣款"],
    );
    return { id: orderId };
  }

  if (action === "developerApply") {
    if (actor.developerStatus === "approved") return { status: "approved" };
    if (actor.developerStatus === "suspended") throw new Error("投稿权限已暂停");
    await sql.query("update profiles set developer_status = 'pending' where user_id = $1", [userId]);
    return { status: "pending" };
  }

  if (action === "mySubmissions") {
    const rows = await sql.query<Row>("select * from submissions where user_id = $1 order by created_at desc limit 30", [userId]);
    return rows.map(submissionCard);
  }

  if (action === "submitComponent") {
    const flags = await configMap(sql);
    if (flags.submissions_open === "false") throw new Error("投稿已关闭");
    if (actor.developerStatus !== "approved") throw new Error("开发者资格还没通过");
    const draft = {
      name: text(body.name, 40),
      slug: text(body.slug, 40).toLowerCase(),
      category: text(body.category, 20),
      summary: text(body.summary, 400),
      version: text(body.version, 20),
      schemaText: text(typeof body.schemaText === "string" ? body.schemaText : "", 20_000),
    };
    const issues = submissionIssues(draft);
    const checks = { issues, at: new Date().toISOString(), policy: "machine-v1" };
    if (issues.length && flags.auto_publish === "true") {
      const submissionId = id("s");
      await sql.query(
        `insert into submissions (id, user_id, name, slug, category, summary, version, schema, status, review_note, checks)
         values ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,'pending',$9,$10::jsonb)`,
        [submissionId, userId, draft.name, draft.slug, draft.category, draft.summary, draft.version, draft.schemaText || "{}", "机器检查未通过，等待人工处理", JSON.stringify(checks)],
      );
      return { id: submissionId, status: "pending", issues };
    }
    if (issues.length) throw new Error(issues[0] || "投稿没有通过检查");
    const taken = await one(sql, "select id from components where slug = $1", [draft.slug]);
    if (taken) throw new Error("这个标识已经被占用");
    const auto = flags.auto_publish === "true";
    const submissionId = id("s");
    await sql.query(
      `insert into submissions (id, user_id, name, slug, category, summary, version, schema, status, review_note, checks, reviewer_id)
       values ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11::jsonb,$12)`,
      [
        submissionId,
        userId,
        draft.name,
        draft.slug,
        draft.category,
        draft.summary,
        draft.version,
        draft.schemaText,
        auto ? "approved" : "pending",
        auto ? "机器检查通过后自动上架" : "",
        JSON.stringify(checks),
        auto ? "policy:auto" : null,
      ],
    );
    if (auto) await publishSubmission(sql, userId, draft);
    return { id: submissionId, status: auto ? "approved" : "pending", issues: [] };
  }

  if (action === "adminOverview") {
    if (!isStaff(actor.roles)) throw new Error("没有权限");
    const [users, members, components, pending, jobs, failed] = await Promise.all([
      one<{ count: number }>(sql, 'select count(*)::int as count from "user"'),
      one<{ count: number }>(sql, "select count(distinct user_id)::int as count from memberships where ends_at > now()"),
      one<{ count: number }>(sql, "select count(*)::int as count from components where status = 'published'"),
      one<{ count: number }>(sql, "select count(*)::int as count from submissions where status = 'pending'"),
      one<{ count: number }>(sql, "select count(*)::int as count from jobs where kind = 'generation' and status = 'succeeded'"),
      one<{ count: number }>(sql, "select count(*)::int as count from jobs where status = 'failed'"),
    ]);
    return {
      users: users?.count ?? 0,
      members: members?.count ?? 0,
      components: components?.count ?? 0,
      pending: pending?.count ?? 0,
      generated: jobs?.count ?? 0,
      failed: failed?.count ?? 0,
      flags: await configMap(sql),
      note: "构建成功数为 0 是预期结果：官方编译器未验证，unavailable 不会被算作成功。",
    };
  }

  if (action === "adminUsers") {
    requirePerm(actor, "users.read");
    const query = text(body.query, 80);
    const rows = await sql.query<Row>(
      `select u.id, u.email, u.name, u."createdAt" as created_at, p.status, p.developer_status
       from "user" u
       left join profiles p on p.user_id = u.id
       where $1 = '' or u.email ilike '%' || $1 || '%' or u.name ilike '%' || $1 || '%'
       order by u."createdAt" desc
       limit 40`,
      [query],
    );
    const list = [];
    for (const row of rows) {
      const idValue = String(row.id);
      list.push({
        id: idValue,
        email: String(row.email),
        name: String(row.name),
        status: row.status ? String(row.status) : "active",
        developerStatus: row.developer_status ? String(row.developer_status) : "none",
        roles: await rolesOf(sql, idValue),
        createdAt: iso(row.created_at),
      });
    }
    return list;
  }

  if (action === "adminUser") {
    requirePerm(actor, "users.read");
    const target = text(body.userId, 80);
    const quota = await quotaView(sql, target);
    const membership = await activeMembership(sql, target);
    const projects = await one<{ count: number }>(sql, "select count(*)::int as count from projects where user_id = $1", [target]);
    const jobs = await sql.query<Row>(
      "select id, kind, status, message, created_at from jobs where user_id = $1 order by created_at desc limit 8",
      [target],
    );
    return {
      quota,
      membership: membership ? { endsAt: iso(membership.ends_at), snapshot: asJson(membership.snapshot) } : null,
      projects: projects?.count ?? 0,
      jobs: jobs.map((row) => ({ id: String(row.id), kind: String(row.kind), status: String(row.status), message: String(row.message), createdAt: iso(row.created_at) })),
    };
  }

  if (action === "adminSetStatus") {
    requirePerm(actor, "users.ban");
    const target = text(body.userId, 80);
    const status = body.status === "banned" ? "banned" : "active";
    if (target === userId && status === "banned") throw new Error("不能封禁自己");
    await sql.query(
      "insert into profiles (user_id, display_name, status) values ($1,'',$2) on conflict (user_id) do update set status = excluded.status",
      [target, status],
    );
    await audit(sql, userId, "user.status", target, null, { status });
    return { ok: true };
  }

  if (action === "adminSetRole") {
    const target = text(body.userId, 80);
    const role = text(body.role, 40);
    const grant = Boolean(body.grant);
    const targetRoles = await rolesOf(sql, target);
    const supers = await one<{ count: number }>(sql, "select count(*)::int as count from user_roles where role = 'super_admin'");
    const message = roleChangeError({
      actorId: userId,
      actorRoles: actor.roles,
      targetId: target,
      targetRoles,
      role,
      grant,
      superAdminCount: supers?.count ?? 0,
    });
    if (message) throw new Error(message);
    if (grant) await sql.query("insert into user_roles (user_id, role) values ($1,$2) on conflict do nothing", [target, role]);
    else await sql.query("delete from user_roles where user_id = $1 and role = $2", [target, role]);
    await audit(sql, userId, "user.role", target, { roles: targetRoles }, { role, grant });
    return { ok: true };
  }

  if (action === "adminGrantQuota") {
    requirePerm(actor, "users.quota");
    const target = text(body.userId, 80);
    const kind = text(body.kind, 20) as QuotaKind;
    const delta = Math.floor(Number(body.delta));
    if (!QUOTA_KINDS.includes(kind) || !Number.isInteger(delta) || delta < -1000 || delta > 1000 || delta === 0) throw new Error("额度调整无效");
    await grantQuota(sql, target, kind, delta, "adjust", `admin:${userId}`, text(body.note, 80) || "管理员调整");
    await audit(sql, userId, "quota.adjust", target, null, { kind, delta });
    return { ok: true };
  }

  if (action === "adminGrantMembership") {
    requirePerm(actor, "users.membership");
    const target = text(body.userId, 80);
    const plan = await one<Row>(sql, "select * from plans where id = $1", [text(body.planId, 40)]);
    if (!plan) throw new Error("套餐不存在");
    await giveMembership(sql, target, plan, `admin:${userId}`);
    await audit(sql, userId, "membership.grant", target, null, { planId: plan.id });
    return { ok: true };
  }

  if (action === "adminGrantComponent") {
    requirePerm(actor, "users.membership");
    const target = text(body.userId, 80);
    const componentId = text(body.componentId, 40);
    const found = await one(sql, "select id from components where id = $1", [componentId]);
    if (!found) throw new Error("组件不存在");
    await sql.query(
      "insert into component_grants (user_id, component_id, source) values ($1,$2,$3) on conflict (user_id, component_id) do update set source = excluded.source",
      [target, componentId, `admin:${userId}`],
    );
    await audit(sql, userId, "component.grant", target, null, { componentId });
    return { ok: true };
  }

  if (action === "adminSetDeveloper") {
    requirePerm(actor, "developer.review");
    const target = text(body.userId, 80);
    const status = text(body.status, 20);
    if (!["none", "pending", "approved", "suspended"].includes(status)) throw new Error("状态无效");
    await sql.query("update profiles set developer_status = $2 where user_id = $1", [target, status]);
    await audit(sql, userId, "developer.status", target, null, { status });
    return { ok: true };
  }

  if (action === "adminComponents") {
    requirePerm(actor, "components.write");
    const rows = await sql.query<Row>("select * from components order by category, name");
    return rows.map((row) => componentCard(row, false));
  }

  if (action === "adminSetComponent") {
    requirePerm(actor, "components.write");
    const componentId = text(body.id, 40);
    const status = body.status === "unpublished" ? "unpublished" : "published";
    const access = text(body.access, 40);
    if (!["public_free", "membership", "license_key", "specific_user", "internal", "disabled"].includes(access)) throw new Error("授权类型无效");
    const before = await one(sql, "select status, access from components where id = $1", [componentId]);
    if (!before) throw new Error("组件不存在");
    await sql.query("update components set status = $2, access = $3 where id = $1", [componentId, status, access]);
    await audit(sql, userId, "component.update", componentId, before, { status, access });
    return { ok: true };
  }

  if (action === "adminSubmissions") {
    requirePerm(actor, "submissions.review");
    const rows = await sql.query<Row>("select * from submissions order by created_at desc limit 40");
    return rows.map(submissionCard);
  }

  if (action === "adminReview") {
    requirePerm(actor, "submissions.review");
    const submissionId = text(body.id, 48);
    const decision = text(body.decision, 20);
    const note = text(body.note, 400);
    const row = await one<Row>(sql, "select * from submissions where id = $1", [submissionId]);
    if (!row) throw new Error("投稿不存在");
    if (!["approve", "reject", "changes"].includes(decision)) throw new Error("决定无效");
    const status = decision === "approve" ? "approved" : decision === "reject" ? "rejected" : "changes";
    if (decision === "approve") {
      const issues = asJson(row.checks) as { issues?: string[] };
      if (issues?.issues?.length) throw new Error("机器检查未通过，不能上架");
      const taken = await one(sql, "select id from components where slug = $1", [row.slug]);
      if (!taken) {
        await publishSubmission(sql, String(row.user_id), {
          name: String(row.name),
          slug: String(row.slug),
          category: String(row.category),
          summary: String(row.summary),
          version: String(row.version),
          schemaText: JSON.stringify(asJson(row.schema)),
        });
      }
    }
    await sql.query("update submissions set status = $2, review_note = $3, reviewer_id = $4 where id = $1", [submissionId, status, note, userId]);
    await audit(sql, userId, "submission.review", submissionId, { status: row.status }, { status, note });
    return { ok: true };
  }

  if (action === "adminPlans") {
    requirePerm(actor, "plans.write");
    const rows = await sql.query<Row>("select * from plans order by price_cents");
    return rows.map(planCard);
  }

  if (action === "adminSavePlan") {
    requirePerm(actor, "plans.write");
    const plan = obj(body.plan);
    const planId = text(plan.id, 40);
    const next = {
      name: text(plan.name, 40),
      priceCents: Math.max(0, Math.floor(Number(plan.priceCents))),
      durationDays: Math.min(3650, Math.max(1, Math.floor(Number(plan.durationDays)))),
      generation: Math.min(100_000, Math.max(0, Math.floor(Number(plan.generation)))),
      build: Math.min(100_000, Math.max(0, Math.floor(Number(plan.build)))),
      export: Math.min(100_000, Math.max(0, Math.floor(Number(plan.export)))),
      concurrency: Math.min(8, Math.max(1, Math.floor(Number(plan.concurrency)))),
      active: plan.active !== false,
    };
    if (!planId || !next.name) throw new Error("套餐不完整");
    const before = await one(sql, "select name, price_cents from plans where id = $1", [planId]);
    await sql.query(
      `update plans set name = $2, price_cents = $3, duration_days = $4, generation = $5, build_quota = $6, export_quota = $7, concurrency = $8, active = $9 where id = $1`,
      [planId, next.name, next.priceCents, next.durationDays, next.generation, next.build, next.export, next.concurrency, next.active],
    );
    await audit(sql, userId, "plan.update", planId, before, next);
    return { ok: true };
  }

  if (action === "adminCreateKeys") {
    requirePerm(actor, "keys.write");
    const type = text(body.type, 20);
    if (!["membership", "quota", "component", "custom"].includes(type)) throw new Error("卡密类型无效");
    const quantity = Math.min(50, Math.max(1, Math.floor(Number(body.quantity))));
    const title = text(body.title, 60) || "卡密批次";
    const payload = obj(body.payload);
    const days = Math.floor(Number(body.expiresInDays ?? 0));
    const expires = days > 0 ? new Date(Date.now() + days * 86_400_000).toISOString() : null;
    if (type === "membership" || payload.planId) {
      const plan = await one(sql, "select id from plans where id = $1", [text(payload.planId, 40)]);
      if (!plan) throw new Error("套餐不存在");
    }
    if (type === "component" || payload.componentId) {
      const component = await one(sql, "select id from components where id = $1", [text(payload.componentId, 40)]);
      if ((type === "component" || payload.componentId) && !component) throw new Error("组件不存在");
    }
    const batchId = id("b");
    await sql.query(
      "insert into license_batches (id, type, title, payload, quantity, created_by) values ($1,$2,$3,$4::jsonb,$5,$6)",
      [batchId, type, title, JSON.stringify(payload), quantity, userId],
    );
    const codes: string[] = [];
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    for (let index = 0; index < quantity; index += 1) {
      const chunk = () => Array.from(randomBytes(4), (byte) => alphabet[byte % alphabet.length]).join("");
      const code = `BH-${chunk()}-${chunk()}`;
      codes.push(code);
      await sql.query(
        "insert into license_keys (id, batch_id, code_hash, hint, type, payload, status, expires_at) values ($1,$2,$3,$4,$5,$6::jsonb,'unused',$7)",
        [id("k"), batchId, createHash("sha256").update(code).digest("hex"), `${code.slice(0, 7)}****`, type, JSON.stringify(payload), expires],
      );
    }
    await audit(sql, userId, "keys.create", batchId, null, { type, quantity });
    return { batchId, codes };
  }

  if (action === "adminKeys") {
    requirePerm(actor, "keys.write");
    const rows = await sql.query<Row>(
      `select k.id, k.hint, k.type, k.status, k.expires_at, k.used_at, b.title
       from license_keys k join license_batches b on b.id = k.batch_id
       order by k.used_at desc nulls last, k.id desc limit 60`,
    );
    return rows.map((row) => ({
      id: String(row.id),
      hint: String(row.hint),
      type: String(row.type),
      status: String(row.status),
      title: String(row.title),
      expiresAt: iso(row.expires_at),
      usedAt: iso(row.used_at),
    }));
  }

  if (action === "adminSetKey") {
    requirePerm(actor, "keys.write");
    const keyId = text(body.id, 48);
    const status = body.status === "void" ? "void" : "frozen";
    const updated = await sql.query(
      "update license_keys set status = $2 where id = $1 and status = 'unused' returning id",
      [keyId, status],
    );
    if (!updated.length) throw new Error("只能冻结或作废未使用的卡密");
    await audit(sql, userId, "keys.status", keyId, { status: "unused" }, { status });
    return { ok: true };
  }

  if (action === "adminOrders") {
    requirePerm(actor, "orders.confirm");
    const rows = await sql.query<Row>("select * from orders order by created_at desc limit 40");
    return rows.map(orderCard);
  }

  if (action === "adminConfirmOrder") {
    requirePerm(actor, "orders.confirm");
    const orderId = text(body.id, 48);
    const decision = body.decision === "cancel" ? "cancel" : "confirm";
    const order = await one<Row>(sql, "select * from orders where id = $1", [orderId]);
    if (!order || order.status !== "pending") throw new Error("订单不在待确认状态");
    if (decision === "cancel") {
      await sql.query("update orders set status = 'cancelled', note = $2 where id = $1", [orderId, text(body.note, 200) || "已取消"]);
      await audit(sql, userId, "order.cancel", orderId, { status: "pending" }, { status: "cancelled" });
      return { ok: true };
    }
    const plan = await one<Row>(sql, "select * from plans where id = $1", [order.plan_id]);
    if (!plan) throw new Error("套餐已不存在");
    await giveMembership(sql, String(order.user_id), plan, `order:${orderId}`);
    await sql.query("update orders set status = 'confirmed', note = $2 where id = $1", [orderId, text(body.note, 200) || "人工确认开通"]);
    await audit(sql, userId, "order.confirm", orderId, { status: "pending" }, { status: "confirmed" });
    return { ok: true };
  }

  if (action === "adminJobs") {
    requirePerm(actor, "jobs.read");
    const rows = await sql.query<Row>(
      "select id, user_id, project_id, kind, status, message, file_name, sha256, created_at from jobs order by created_at desc limit 40",
    );
    return rows.map((row) => ({ ...publicJob(row), userId: String(row.user_id) }));
  }

  if (action === "adminAnnouncements") {
    requirePerm(actor, "announce.write");
    const rows = await sql.query<Row>("select id, title, body, active, created_at from announcements order by created_at desc limit 20");
    return rows.map((row) => ({ id: String(row.id), title: String(row.title), body: String(row.body), active: Boolean(row.active), createdAt: iso(row.created_at) }));
  }

  if (action === "adminSaveAnnouncement") {
    requirePerm(actor, "announce.write");
    const title = text(body.title, 60);
    const message = text(body.body, 600);
    const active = body.active !== false;
    if (!title || !message) throw new Error("公告不完整");
    const announcementId = text(body.id, 40) || id("ann");
    await sql.query(
      `insert into announcements (id, title, body, active) values ($1,$2,$3,$4)
       on conflict (id) do update set title = excluded.title, body = excluded.body, active = excluded.active`,
      [announcementId, title, message, active],
    );
    await audit(sql, userId, "announcement.save", announcementId, null, { title, active });
    return { ok: true };
  }

  if (action === "adminConfig") {
    requirePerm(actor, "config.write");
    return configMap(sql);
  }

  if (action === "adminSetConfig") {
    requirePerm(actor, "config.write");
    const key = text(body.key, 40);
    const value = body.value === true || body.value === "true" ? "true" : "false";
    if (!CONFIG_KEYS.includes(key as (typeof CONFIG_KEYS)[number])) throw new Error("没有这个开关");
    const before = await configMap(sql);
    await sql.query(
      "insert into system_config (key, value) values ($1,$2) on conflict (key) do update set value = excluded.value",
      [key, value],
    );
    await audit(sql, userId, "config.update", key, { value: before[key] }, { value });
    return { ok: true };
  }

  if (action === "adminAudit") {
    requirePerm(actor, "audit.read");
    const rows = await sql.query<Row>("select id, actor_id, action, target, before, after, created_at from audit_logs order by created_at desc limit 50");
    return rows.map((row) => ({
      id: String(row.id),
      actorId: String(row.actor_id),
      action: String(row.action),
      target: String(row.target),
      before: asJson(row.before),
      after: asJson(row.after),
      createdAt: iso(row.created_at),
    }));
  }

  if (action === "ledger") {
    const rows = await sql.query<Row>(
      "select id, kind, delta, phase, ref, note, created_at from quota_ledger where user_id = $1 order by created_at desc limit 30",
      [userId],
    );
    return rows.map((row) => ({
      id: String(row.id),
      kind: String(row.kind),
      delta: Number(row.delta),
      phase: String(row.phase),
      note: String(row.note),
      createdAt: iso(row.created_at),
    }));
  }

  throw new Error("未知操作");
}

function orderCard(row: Row) {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    planId: String(row.plan_id),
    status: String(row.status),
    amountCents: Number(row.amount_cents),
    snapshot: asJson(row.snapshot),
    note: String(row.note ?? ""),
    createdAt: iso(row.created_at),
  };
}

function submissionCard(row: Row) {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    name: String(row.name),
    slug: String(row.slug),
    category: String(row.category),
    summary: String(row.summary),
    version: String(row.version),
    status: String(row.status),
    reviewNote: String(row.review_note ?? ""),
    checks: asJson(row.checks),
    createdAt: iso(row.created_at),
  };
}

async function publishSubmission(
  sql: Sql,
  _userId: string,
  draft: { name: string; slug: string; category: string; summary: string; version: string; schemaText: string },
) {
  const componentId = `cmp_${draft.slug}`.slice(0, 48);
  await sql.query(
    `insert into components (id, slug, name, category, summary, author_name, access, min_plan, status, latest_version)
     values ($1,$2,$3,$4,$5,'开发者','public_free','','published',$6)
     on conflict (slug) do nothing`,
    [componentId, draft.slug, draft.name, draft.category, draft.summary, draft.version],
  );
  const component = await one<{ id: string }>(sql, "select id from components where slug = $1", [draft.slug]);
  if (!component) return;
  await sql.query(
    "insert into component_versions (id, component_id, version, changelog) values ($1,$2,$3,$4) on conflict (component_id, version) do nothing",
    [id("ver"), component.id, draft.version, "投稿上架。只进入商城目录，不会变成新的 BlueOS 标签。"],
  );
}
