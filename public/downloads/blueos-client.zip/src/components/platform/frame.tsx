import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { DownloadBar } from "@/components/platform/downloads";
import { useMe } from "@/lib/platform/client";

const LINKS = [
  { to: "/", label: "工程" },
  { to: "/market", label: "商城" },
  { to: "/account", label: "权益" },
  { to: "/developer", label: "投稿" },
  { to: "/jobs", label: "任务" },
] as const;

export function RequireUser({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <main className="grid min-h-dvh place-items-center text-sm text-muted">正在核对登录…</main>;
  if (!user) return <RedirectToSignIn />;
  return children;
}

export function AppFrame({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const { data } = useMe<{ staff: boolean; announcements: { id: string; title: string }[] }>();
  return (
    <div className="min-h-dvh">
      <header className="glass sticky top-0 z-30 border-b border-line">
        <div className="mx-auto flex w-full max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="grid size-9 place-items-center rounded-xl border border-line bg-surface shadow-sm">
              <span className="size-4 rounded-full border-2 border-accent" />
            </span>
            <span className="text-sm font-semibold tracking-tight">BlueOS 工坊</span>
          </Link>
          <nav className="studio-scroll flex min-w-0 flex-1 gap-1 overflow-x-auto">
            {LINKS.map((link) => {
              const active = link.to === "/" ? path === "/" : path.startsWith(link.to);
              return (
                <Link key={link.to} to={link.to} className={`shrink-0 rounded-md px-3 py-2 text-sm ${active ? "bg-surface-2 text-fg" : "text-muted"}`}>
                  {link.label}
                </Link>
              );
            })}
            {data?.staff ? (
              <Link to="/admin" className={`shrink-0 rounded-md px-3 py-2 text-sm ${path.startsWith("/admin") ? "bg-surface-2 text-fg" : "text-muted"}`}>
                后台
              </Link>
            ) : null}
          </nav>
          <UserButton />
        </div>
      </header>
      {data?.announcements?.[0] ? (
        <p className="border-b border-line bg-bg px-4 py-2 text-center text-xs text-muted">{data.announcements[0].title}</p>
      ) : null}
      {children}
      <DownloadBar />
    </div>
  );
}
